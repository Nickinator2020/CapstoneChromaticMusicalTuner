[AC Analysis]
{
   Npanes: 1
   {
      traces: 1 {589828,0,"V(vout_shift)"}
      X: ('K',0,1,0,10000)
      Y[0]: (' ',0,0.0794328234724281,2,1)
      Y[1]: (' ',0,-100,20,80)
      Log: 1 2 0
      PltMag: 1
   }
}
